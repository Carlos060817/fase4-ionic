import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saidas',
  templateUrl: './saidas.page.html',
  styleUrls: ['./saidas.page.scss'],
})
export class SaidasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
