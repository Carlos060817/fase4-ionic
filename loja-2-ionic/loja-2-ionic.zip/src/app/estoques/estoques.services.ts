import { Injectable } from '@angular/core';
import { Estoque } from './estoques.moduls';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ListService {

   baseUrl = "http://localhost:3000/produtos"
  constructor(private http : HttpClient) {

   }

   getEstoque() : Observable<Estoque[]> {
     return this.http.get<Estoque[]>(this.baseUrl)
   }

   getItemEstoque(id : number) : Observable<Estoque>{
     const url = `${this.baseUrl}/${id}`
     return this.http.get<Estoque>(url)
  }


  adicionarQuantidade(id:number,cod:number,nome:string,entrada:number,saida:number,qtde:number, quantidade_inserida:number) : Observable<Estoque>{
    //this.produtos[i].qtde = this.produtos[i].qtde + quantidade_inserida;
    let produto = new Estoque(id,cod,nome,entrada,saida,qtde)
    const url = `${this.baseUrl}/${id}`
    return this.http.put<Estoque>(url,produto)
  }
/*
  removerQuantidade(i:number, quantidade_inserida:number){
    this.produtos[i].qtde = this.produtos[i].qtde - quantidade_inserida;
  }

  adicionarSaida(i:number, saida_inserida:number){
    this.produtos[i].saida = this.produtos[i].saida + saida_inserida;

  }

  removerSaida(i:number,saida_inserida:number){
    this.produtos[i].saida = this.produtos[i].saida - saida_inserida;
  }

  adicionarEntrada(i:number,valor_inserido:number){
    this.produtos[i].entrada = this.produtos[i].entrada + valor_inserido;
  }

  removerEntrada(i:number,valor_inserido:number){

    this.produtos[i].entrada = this.produtos[i].entrada - valor_inserido;

  }

*/

   addProduto(id:number,cod:number,nome:string,entrada:number,saida:number,qtde:number) : Observable<Estoque>{
   let produto = new Estoque(id,cod,nome,entrada,saida,qtde)
    return this.http.post<Estoque>(this.baseUrl,produto)
   }

}
