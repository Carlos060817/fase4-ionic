import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Update } from '../update/update.moduls';
import { ListService } from '../estoques/estoques.services';
import { Estoque } from '../estoques/estoques.moduls';

@Component({
  selector: 'app-update',
  templateUrl: './update.page.html',
  styleUrls: ['./update.page.scss'],
})
export class UpdatePage implements OnInit {

  index: number = 0;
  produto: Estoque = null;
  // produtoSelected: Estoque;
  quantidade: number = 0;
  valor: number = 0;
  saida: number = 0;
  id: number = 0;
  produtos: Estoque[]=[]

  constructor(private route:ActivatedRoute, public estoqueService:ListService,private router : Router) {
    this.index = this.route.snapshot.params.id;
   estoqueService.getItemEstoque(this.index).subscribe((produto) => {
      this.produtos[0] = produto});
   }

   ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.estoqueService.getItemEstoque(this.id).subscribe((produto) => {
      this.produto = produto
      this.quantidade = this.produto.qtde
      this.valor = this.produto.entrada
      this.saida = this.produto.saida
    });
  }


  onSubmit(from:any){

  }

  //quantidade
  /*
  adicionar(): void{
    this.estoqueService.adicionarQuantidade(this.index, this.quantidade);
  }

  remover(): void{
    this.estoqueService.removerQuantidade(this.index, this.quantidade);
  }

  //saida
  adicionar1(): void{
    this.estoqueService.adicionarSaida(this.index,this.saida);
  }

  remover1(): void{
    this.estoqueService.removerSaida(this.index,this.saida);
  }

//entrada
  adicionar2(): void{
    this.estoqueService.adicionarEntrada(this.index,this.valor);
  }

  remover2(): void{
    this.estoqueService.removerEntrada(this.index,this.valor);
  }
  */
}
